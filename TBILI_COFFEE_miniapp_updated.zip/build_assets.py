from pathlib import Path
import re, html

ROOT=Path('/mnt/data/tbilicoffee_inspect')
AS=ROOT/'assets'
AS.mkdir(exist_ok=True)

# Product visual type hints: beverage / cold / bubble / pastry / dessert / food
beverage_ids=set('espresso double americano250 capp250 capp350 latte flat raf mocha cocoa icelatte iceamericano icevanilla icecaramel tonic cherryespresso bubble-strawberry bubble-mango bubble-passion bubble-taro bubble-blood butterbeer negative salvatore nevermore trick central midnight dino luke eleven double-r lemonade-strawberry lemonade-passion lemonade-cherry matcha hotchoc tea'.split())
pastry_ids=set('croissant choccroissant almondcroissant caramelcroissant waffle waffle-eleven appleturnover cherryturnover cookie redvelvetcookie cheesecake mini-cheesecake'.split())

# color palette per theme
pal={
 'black':('#242424','#0a0a0a','#f3f3f3'),
 'gold':('#b36b20','#2a1206','#ffd18a'),
 'red':('#ef1e36','#35070d','#ff9aa6'),
 'purple':('#8a55c7','#170c27','#d8b9ff'),
}

def esc(s): return html.escape(s, quote=True)

def svg_for(pid, name, theme, kind='drink'):
    c1,c2,hi=pal.get(theme,pal['black'])
    # decorative background and object
    if kind=='drink':
        obj=f'''<g filter="url(#shadow)">
          <ellipse cx="200" cy="330" rx="78" ry="18" fill="#000" opacity=".45"/>
          <path d="M132 126 Q200 105 268 126 L252 302 Q200 330 148 302 Z" fill="url(#liquid)" stroke="#f4f4f4" stroke-opacity=".18" stroke-width="3"/>
          <path d="M138 140 Q200 160 262 140 L258 165 Q200 184 142 165 Z" fill="#fff" opacity=".09"/>
          <ellipse cx="200" cy="126" rx="68" ry="20" fill="#151515" stroke="#fff" stroke-opacity=".2" stroke-width="3"/>
          <ellipse cx="200" cy="126" rx="56" ry="13" fill="{c1}" opacity=".9"/>
          <path d="M178 105 C172 80 190 62 200 50 C210 62 228 80 222 105" fill="none" stroke="{hi}" stroke-width="7" stroke-linecap="round" opacity=".8"/>
          <circle cx="170" cy="190" r="5" fill="#fff" opacity=".35"/><circle cx="230" cy="230" r="4" fill="#fff" opacity=".28"/>
        </g>'''.replace('{hi}',hi)
        if pid.startswith('ice') or pid in {'tonic','cherryespresso','lemonade-strawberry','lemonade-passion','lemonade-cherry'}:
            obj += '<g opacity=".8"><rect x="155" y="165" width="35" height="35" rx="7" fill="#dff5ff" transform="rotate(12 172 182)"/><rect x="210" y="185" width="34" height="34" rx="7" fill="#dff5ff" transform="rotate(-18 227 202)"/></g>'
        if pid.startswith('bubble') or pid=='blood':
            for x,y,r in [(164,245,8),(188,270,6),(217,250,9),(236,280,6),(202,295,5)]:
                obj += f'<circle cx="{x}" cy="{y}" r="{r}" fill="#1b1016" stroke="#fff" stroke-opacity=".25"/>'
        if pid in {'raf','capp250','capp350','central','nevermore','hotchoc','butterbeer'}:
            obj += '<path d="M160 120 Q200 90 240 120" fill="none" stroke="#fff" stroke-opacity=".45" stroke-width="12" stroke-linecap="round"/>'
    elif kind=='waffle':
        obj='''<g filter="url(#shadow)"><ellipse cx="200" cy="330" rx="92" ry="17" fill="#000" opacity=".45"/><rect x="115" y="115" width="170" height="170" rx="28" fill="#c98b37" transform="rotate(-5 200 200)"/><path d="M135 145h130M125 180h150M120 215h160M128 250h144M155 120v165M195 115v170M235 120v165M270 135v145" stroke="#75420f" stroke-width="13" opacity=".75"/><path d="M145 135h110M135 170h130" stroke="#ffd58a" stroke-width="5" opacity=".5"/></g>'''
    elif kind=='croissant':
        obj='''<g filter="url(#shadow)"><ellipse cx="200" cy="310" rx="105" ry="18" fill="#000" opacity=".45"/><path d="M105 225 C112 145 165 105 200 142 C235 105 288 145 295 225 C265 260 235 272 200 242 C165 272 135 260 105 225Z" fill="#d8943f"/><path d="M140 154 Q130 205 160 244 M178 142 Q165 204 190 250 M220 142 Q235 204 210 250 M260 154 Q270 205 240 244" fill="none" stroke="#7c3f12" stroke-width="12" opacity=".65"/><path d="M125 190 Q200 145 275 190" fill="none" stroke="#ffd58a" stroke-width="7" opacity=".45"/></g>'''
    elif kind=='cookie':
        obj='''<g filter="url(#shadow)"><ellipse cx="200" cy="300" rx="92" ry="18" fill="#000" opacity=".45"/><circle cx="200" cy="205" r="92" fill="#9b5a2b"/><circle cx="164" cy="170" r="11" fill="#3b1b0b"/><circle cx="224" cy="155" r="12" fill="#3b1b0b"/><circle cx="245" cy="220" r="10" fill="#3b1b0b"/><circle cx="177" cy="235" r="12" fill="#3b1b0b"/><circle cx="215" cy="265" r="8" fill="#3b1b0b"/><path d="M145 135 Q200 110 255 135" stroke="#ffd08b" stroke-width="8" opacity=".35" fill="none"/></g>'''
    elif kind=='cake':
        obj='''<g filter="url(#shadow)"><ellipse cx="200" cy="315" rx="100" ry="17" fill="#000" opacity=".45"/><path d="M115 170 L285 170 L268 280 Q200 305 132 280Z" fill="#f0dfd2"/><path d="M125 205 L275 205 L270 235 Q200 260 130 235Z" fill="#c68c6c"/><path d="M115 165 Q200 135 285 165 L270 190 Q200 215 130 190Z" fill="#fff0e7"/><circle cx="175" cy="155" r="10" fill="#e21b2d"/><circle cx="225" cy="150" r="10" fill="#e21b2d"/></g>'''
    elif kind=='tart':
        obj='''<g filter="url(#shadow)"><ellipse cx="200" cy="315" rx="105" ry="17" fill="#000" opacity=".45"/><circle cx="200" cy="205" r="100" fill="#9a5420"/><circle cx="200" cy="195" r="80" fill="#e2a044"/><path d="M145 160 Q200 210 255 160 M135 205 Q200 250 265 205" fill="none" stroke="#fff0bd" stroke-width="12" opacity=".65"/><circle cx="150" cy="175" r="9" fill="#b51d27"/><circle cx="245" cy="175" r="9" fill="#b51d27"/></g>'''
    else:
        obj='''<g filter="url(#shadow)"><ellipse cx="200" cy="310" rx="95" ry="17" fill="#000" opacity=".45"/><rect x="120" y="125" width="160" height="150" rx="32" fill="url(#liquid)"/><path d="M135 155 Q200 120 265 155" fill="none" stroke="#fff" stroke-opacity=".3" stroke-width="8"/></g>'''.replace('url(#liquid)', 'url(#liquid)')
    # SVG with gradients
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">
<defs><radialGradient id="bg"><stop offset="0" stop-color="{c1}" stop-opacity=".9"/><stop offset=".55" stop-color="{c2}"/><stop offset="1" stop-color="#080808"/></radialGradient><linearGradient id="liquid" x1="0" y1="0" x2="1" y2="1"><stop stop-color="{c1}"/><stop offset="1" stop-color="{c2}"/></linearGradient><filter id="shadow"><feDropShadow dx="0" dy="14" stdDeviation="12" flood-color="#000" flood-opacity=".65"/></filter></defs>
<rect width="400" height="400" rx="28" fill="url(#bg)"/>
<circle cx="320" cy="70" r="90" fill="{c1}" opacity=".14"/>
<circle cx="75" cy="330" r="70" fill="{hi}" opacity=".06"/>
{obj}
<text x="24" y="370" font-family="Arial, sans-serif" font-size="12" letter-spacing="3" fill="#fff" opacity=".55">TBILI • COFFEE</text>
</svg>'''

# Map product data from current HTML lines
htmltxt=(ROOT/'index.html').read_text(encoding='utf-8')
pat=re.compile(r"\{id:'([^']+)',cat:'([^']+)',name:'([^']+)',price:\d+,vol:'([^']*)',emoji:'[^']*',theme:'([^']+)',desc:'([^']*)'(?:,tag:'[^']*')?\}")
items=pat.findall(htmltxt)
for pid,cat,name,vol,theme,desc in items:
    if pid in pastry_ids or cat=='bakery': kind='croissant' if 'круас' in name.lower() else 'waffle' if 'ваф' in name.lower() else 'cookie' if 'cookie' in name.lower() or 'печень' in name.lower() else 'cake'
    elif cat=='dessert': kind='cake' if 'чиз' in name.lower() or 'медов' in name.lower() or 'velvet' in name.lower() else 'tart' if 'тарт' in name.lower() else 'cookie'
    else: kind='drink'
    (AS/f'{pid}.svg').write_text(svg_for(pid,name,theme,kind),encoding='utf-8')
print('generated', len(items), 'product assets')
